from lavendeux import Types

def call(args):
	return(Types.INT, 5)

def decorate(value):
	return "FIVE"